# controller
A GoDot 4+ Addon to create controllers that interact with Node Signals
