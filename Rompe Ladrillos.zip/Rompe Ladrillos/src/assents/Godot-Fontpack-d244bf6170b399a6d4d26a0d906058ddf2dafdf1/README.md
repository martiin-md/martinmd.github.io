# Godot-Fontpack
A collection of open fonts ready to use in Godot projects.

Each font folder contains the .tres file for Godot, additional font versions if they available and its license file.

Preview of all fonts in this pack:

![alt text](https://raw.githubusercontent.com/dalton5000/Godot-Fontpack/master/fonts/overview.PNG "Preview Image")
