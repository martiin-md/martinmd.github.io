# Rompe Ladrillos - Godot 4.3


## Características del juego
